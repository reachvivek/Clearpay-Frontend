export const environment = {
  BASE_PATH: 'https://clearpay-papi.cms.com:5001',
  KEY: '30e3c0b9936c6cfce4ae18a40f135b5f',
};
