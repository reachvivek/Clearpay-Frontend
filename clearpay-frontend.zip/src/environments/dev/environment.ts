export const environment = {
  BASE_PATH: 'http://localhost:3000',
};
